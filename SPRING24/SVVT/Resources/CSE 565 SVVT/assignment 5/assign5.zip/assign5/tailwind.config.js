/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./*.html", "./v1/*.html"],
  theme: {
    extend: {},
  },
  plugins: [],
};
